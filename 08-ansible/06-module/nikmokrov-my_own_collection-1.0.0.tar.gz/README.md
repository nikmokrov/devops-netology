# Ansible Collection - nikmokrov.my_own_collection

This is my_own_collection for my_own_module ansible module
